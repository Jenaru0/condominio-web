// src/Routes.js
import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import ProtectedLayout from "layouts/ProtectedLayout";
import ProtectedRoute from "./ProtectedRoute"; // Ajuste aquí
import LoginPage from " ../paginas/Autenticacion/LoginPage";
import Dashboard from "pages/Dashboard/Dashboard";
import ResidentesInquilinos from "pages/Usuarios/ResidentesInquilinos"; // Ajuste si corresponde
import GestionCocheras from "pages/Propiedades/GestionCocheras";
import Reportes from "pages/Reportes/Reportes";
import SolicitudesMantenimiento from "pages/Mantenimiento/SolicitudesMantenimiento"; // Ajuste aquí
import EnvioNotificaciones from "pages/Notificaciones/EnvioNotificaciones"; // Ajuste aquí
import GestionCorrespondencia from "pages/Correspondencia/GestionCorrespondencia"; // Ajuste aquí
import EventosCondominio from "pages/Eventos/EventosCondominio"; // Ajuste aquí
import ControlMonitoreoAccesos from "pages/Seguridad/ControlMonitoreoAccesos"; // Ajuste aquí
import GestionContratos from "pages/Documentos/GestionContratos"; // Ajuste aquí
import AyudaSoporte from "pages/AyudaSoporte/AyudaSoporte"; // Ajuste aquí
import Configuracion from "pages/Configuracion/Configuracion"; // Ajuste aquí
import Usuario from "pages/Usuarios/Usuario"; // Ajuste aquí
import ReportePagos from "pages/Reportes/ReportePagos"; // Ajuste aquí
import ReporteMantenimiento from "pages/Reportes/ReporteMantenimiento"; // Ajuste aquí
import ReporteCorrespondencia from "pages/Reportes/ReporteCorrespondencia"; // Ajuste aquí
import GestionUsuarios from "pages/Usuarios/GestionUsuarios"; // Ajuste aquí

const AppRoutes = () => {
  return (
    <Routes>
      {/* Rutas públicas (login) */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/" element={<Navigate to="/login" />} />

      {/* Rutas protegidas (con Sidebar) */}
      <Route element={<ProtectedLayout />}>
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/residentes-inquilinos"
          element={
            <ProtectedRoute>
              <ResidentesInquilinos />
            </ProtectedRoute>
          }
        />
        <Route
          path="/gestion-cocheras"
          element={
            <ProtectedRoute>
              <GestionCocheras />
            </ProtectedRoute>
          }
        />
        <Route
          path="/reportes"
          element={
            <ProtectedRoute>
              <Reportes />
            </ProtectedRoute>
          }
        />
        <Route
          path="/solicitudes-mantenimiento"
          element={
            <ProtectedRoute>
              <SolicitudesMantenimiento />
            </ProtectedRoute>
          }
        />
        <Route
          path="/envio-notificaciones"
          element={
            <ProtectedRoute>
              <EnvioNotificaciones />
            </ProtectedRoute>
          }
        />
        <Route
          path="/gestion-correspondencia"
          element={
            <ProtectedRoute>
              <GestionCorrespondencia />
            </ProtectedRoute>
          }
        />
        <Route
          path="/eventos-condominio"
          element={
            <ProtectedRoute>
              <EventosCondominio />
            </ProtectedRoute>
          }
        />
        <Route
          path="/control-monitoreo-accesos"
          element={
            <ProtectedRoute>
              <ControlMonitoreoAccesos />
            </ProtectedRoute>
          }
        />
        <Route
          path="/gestion-contratos"
          element={
            <ProtectedRoute>
              <GestionContratos />
            </ProtectedRoute>
          }
        />
        <Route
          path="/ayuda-soporte"
          element={
            <ProtectedRoute>
              <AyudaSoporte />
            </ProtectedRoute>
          }
        />
        <Route
          path="/configuracion"
          element={
            <ProtectedRoute>
              <Configuracion />
            </ProtectedRoute>
          }
        />
        <Route
          path="/usuario"
          element={
            <ProtectedRoute>
              <Usuario />
            </ProtectedRoute>
          }
        />
        <Route
          path="/reporte-pagos"
          element={
            <ProtectedRoute>
              <ReportePagos />
            </ProtectedRoute>
          }
        />
        <Route
          path="/reporte-mantenimiento"
          element={
            <ProtectedRoute>
              <ReporteMantenimiento />
            </ProtectedRoute>
          }
        />
        <Route
          path="/reporte-correspondencia"
          element={
            <ProtectedRoute>
              <ReporteCorrespondencia />
            </ProtectedRoute>
          }
        />
        <Route
          path="/gestion-usuarios"
          element={
            <ProtectedRoute>
              <GestionUsuarios />
            </ProtectedRoute>
          }
        />
      </Route>
    </Routes>
  );
};

export default AppRoutes;
