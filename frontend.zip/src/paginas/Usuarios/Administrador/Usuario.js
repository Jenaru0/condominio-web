import React from 'react';

const Usuario = () => {
  return <div>Usuario</div>;
};

export default Usuario;
