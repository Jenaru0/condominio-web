import React from "react";

const GestionCocheras = () => {
  return (
    <div>
      <h1>Gestion de Cocheras</h1>
    </div>
  );
};

export default GestionCocheras;
