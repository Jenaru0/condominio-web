// En src/paginas/Notificaciones/Administrador/EnviarNotificaciones.js

import React from "react";

const EnviarNotificaciones = () => {
  // Código del componente
  return <div>Enviar Notificaciones</div>;
};

export default EnviarNotificaciones;
