import React from 'react';

const Reportes = () => {
  return <div>Reportes</div>;
};

export default Reportes;
