import React from 'react';

const AyudaSoporte = () => {
  return <div>Ayuda y Soporte</div>;
};

export default AyudaSoporte;
