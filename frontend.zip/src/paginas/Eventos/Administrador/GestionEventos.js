import React from "react";

const GestionEventos = () => {
  return <div>Contenido del componente</div>;
};

export default GestionEventos;
