import React from 'react';

const Configuracion = () => {
  return <div>Configuración</div>;
};

export default Configuracion;
